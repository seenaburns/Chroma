History
-------

0.1.0 (2012-12-15)
------------------
- Initial Release
- RGB and Hex support
