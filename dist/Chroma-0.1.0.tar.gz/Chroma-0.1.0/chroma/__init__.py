"""
chroma
~~~~~~~~

Main module

"""

from .core import *

__title__ = 'chroma'
__version__ = '0.1.0'
__author__ = 'Seena Burns'
__license__ = 'BSD'
__copyright__ = 'Copyright 2012 Seena Burns'
